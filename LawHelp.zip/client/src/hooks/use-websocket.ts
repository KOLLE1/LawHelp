import { useEffect, useRef, useState } from "react";
import type { WSMessage } from "@/types";

export interface UseWebSocketOptions {
  token?: string;
  onMessage: (msg: WSMessage) => void;
}

export function useWebSocket({ token, onMessage }: UseWebSocketOptions) {
  const socketRef = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    const url = `ws://localhost:5000/ws`;
    const socket = new WebSocket(url);
    socketRef.current = socket;

    socket.onopen = () => {
      setIsConnected(true);
      if (token) {
        const authMessage: WSMessage = {
          type: "auth",
          token,
        };
        socket.send(JSON.stringify(authMessage));
      }
    };

    socket.onmessage = (event) => {
      try {
        const parsed: WSMessage = JSON.parse(event.data);
        onMessage(parsed);
      } catch (error) {
        console.error("Invalid WebSocket message:", error);
      }
    };

    socket.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    socket.onclose = () => {
      setIsConnected(false);
      console.warn("WebSocket disconnected");
    };

    return () => {
      socket.close();
    };
  }, [token, onMessage]);

  const sendMessage = (msg: WSMessage): boolean => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify(msg));
      return true;
    }
    return false;
  };

  return {
    sendMessage,
    isConnected,
  };
}
