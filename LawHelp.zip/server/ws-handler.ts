import { WebSocket } from "ws";
import { createMessage } from "./lib/messages";
import { getAnswerFromAI } from "./routes/chatbot";

interface WSMessage {
  type: "auth" | "user_message";
  token?: string;
  sessionId?: string;
  content?: string;
}

interface ExtendedWebSocket extends WebSocket {
  userId?: string;
}

export async function handleWebSocketMessage(
  message: WSMessage,
  userId: string,
  socket: WebSocket
) {
  try {
    if (message.type === "user_message" && message.content && message.sessionId) {
      const { sessionId, content } = message;

      // 1. Save user message
      await createMessage({
        role: "user", // ✅ explicitly set to "user"
        content,
        userId,
        sessionId,
      });

      // 2. Confirm message sent
      socket.send(JSON.stringify({
        type: "message_sent",
        sessionId,
        content,
      }));

      // 3. Generate AI reply
      const aiResponse = await getAnswerFromAI(content);
      const aiText = aiResponse.answer;

      // 4. Save AI message
      await createMessage({
        role: "ai", // ✅ explicitly set to "ai"
        content: aiText,
        userId,
        sessionId,
      });

      // 5. Send AI response to frontend
      socket.send(JSON.stringify({
        type: "ai_response",
        sessionId,
        content: aiText,
      }));
    }
  } catch (err) {
    console.error("WebSocket processing error:", err);
    socket.send(JSON.stringify({
      type: "error",
      message: "Something went wrong on the server.",
    }));
  }
}
